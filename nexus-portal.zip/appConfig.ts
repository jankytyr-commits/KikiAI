
export const appConfig = {
  urls: {
    "kiki-ai": "http://www.ekobio.org/apps/kikiai/",
    "kicommander": "http://www.ekobio.org/apps/commandergem/",
    "default": "http://www.ekobio.org/"
  }
};

export default appConfig;
